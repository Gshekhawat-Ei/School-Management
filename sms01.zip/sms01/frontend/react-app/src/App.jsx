import React from 'react';
import Navbar from './component/Navbar';
import Sidebar from './component/SideNav';
import Center  from './component/center';
// import StudentList from './component/StudentList';
const Home = () => {
  return (
    <div >
      
      <Navbar />
      <Sidebar />
      <Center className="centerItem" />
     
      
     
    </div>
  );
};

export default Home;
