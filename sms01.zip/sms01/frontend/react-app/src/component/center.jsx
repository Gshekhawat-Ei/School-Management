
import React, { useState } from 'react';
import SideNav from './SideNav'; 
import ClassList from './ClassList';
import TeacherList from './TeacherList';
import StudentList from './StudentList';

const Center = () => {
  const [selectedComponent, setSelectedComponent] = useState(null);

  const handleSelect = (type) => {
    setSelectedComponent(type);
  };

  const renderComponent = () => {
    switch (selectedComponent) {
      case 'class':
        return <ClassList />;
      case 'teacher':
        return <TeacherList />;
      case 'student':
        return <StudentList />;
      default:
        return <div>Please select an option from the sidebar.</div>;
    }
  };

  return (
    <div style={{ display: 'flex' }}>
      <SideNav onSelect={handleSelect} />
      <div style={{ marginLeft: '20px', flex: 1 }}>
        {renderComponent()}
      </div>
    </div>
  );
};

export default Center;
