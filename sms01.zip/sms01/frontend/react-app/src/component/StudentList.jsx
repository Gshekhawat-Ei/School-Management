// // src/components/StudentList.js
// import React, { useEffect, useState } from 'react';
// import axios from 'axios';


// const StudentList = () => {
//   const [students, setStudents] = useState([]);
//   const [loading, setLoading] = useState(true);

//   const fetchStudents = async () => {
//     try {
//       const response = await axios.get('http://localhost:5000/students'); 
//       setStudents(response.data);
//       setLoading(false);
//     } catch (error) {
//       console.error('Error fetching students:', error);
//       setLoading(false);
//     }
//   };

//   useEffect(() => {
//     fetchStudents();
//   }, []);

//   if (loading) {
//     return <div className="loading">Loading...</div>;
//   }

//   return (
//     <div className="student-list-container">
//       <h2>Student List</h2>
//       <ul className="student-list">
//         {students.map((student) => (
//           <li key={student._id}>
//             Name: {student.name}, Age: {student.age}, Class: {student.class}
//           </li>
//         ))}
//       </ul>
//     </div>
//   );
// };

// export default StudentList;





// StudentList.jsx
import React, { useEffect, useState } from 'react';
import axios from 'axios';

const StudentList = () => {
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStudents = async () => {
      try {
        const response = await axios.get('http://localhost:5000/students');
        setStudents(response.data);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching students:', error);
        setLoading(false);
      }
    };

    fetchStudents();
  }, []);

  if (loading) {
    return <div className="loading">Loading...</div>;
  }

  return (
    <div className="list-container">
      <h2>Student List</h2>
      <ul className="list">
        {students.map((student) => (
          <li key={student._id}>
            Name: {student.name}, Age: {student.age}, Class: {student.class}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default StudentList;
