// src/components/TeacherList.js
import React, { useEffect, useState } from 'react';
import axios from 'axios';

const TeacherList = () => {
  const [teachers, setTeachers] = useState([]);
  const [loading, setLoading] = useState(true);

  // Function to fetch teachers from the backend
  const fetchTeachers = async () => {
    try {
      const response = await axios.get('http://localhost:5000/teachers'); // Ensure the backend endpoint is correct
      setTeachers(response.data);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching teachers:', error);
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTeachers();
  }, []);

  if (loading) {
    return <div className="loading">Loading...</div>;
  }

  return (
    <div className="list-container"> {/* Updated class name to match the shared CSS */}
      <h2>Teacher List</h2>
      <ul className="list"> {/* Updated class name to match the shared CSS */}
        {teachers.map((teacher) => (
          <li key={teacher._id}>
            Name: {teacher.name}, Subject: {teacher.subject}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default TeacherList;
