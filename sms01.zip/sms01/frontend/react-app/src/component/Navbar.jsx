import React from 'react';

// Navbar Component
const Navbar = () => {
  return (
    <nav style={styles.navbar}>
      <h1 style={styles.title}>Navbar</h1>
      <button style={styles.button}>Button1</button> {/* Add Button on the Right Side */}
    </nav>
  );
};

// Inline Styles
const styles = {
  navbar: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: '10px 20px',
    backgroundColor: ' black', // Change background to blue
    color: '#fff',
  },
  title: {
    margin: 0,
    fontSize: '24px',
  },
  button: {
    padding: '8px 16px',
    backgroundColor: '#fff',
    color: 'blue',
    border: 'none',
    borderRadius: '4px',
    cursor: 'pointer',
  },
};

export default Navbar;
