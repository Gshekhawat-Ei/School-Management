
import React from 'react';

const SideNar = ({ onSelect }) => {
  // Handle click events and call the onSelect function with the appropriate component type
  const handleSelect = (type) => {
    onSelect(type);
  };

  return (
    <aside style={styles.sidebar}>
      <h2 style={styles.title}>School Management</h2>
      <ul style={styles.list}>
        <li style={styles.listItem}>
          <button onClick={() => handleSelect('class')}>Class</button>
        </li>
        <li style={styles.listItem}>
          <button onClick={() => handleSelect('teacher')}>Teacher</button>
        </li>
        <li style={styles.listItem}>
          <button onClick={() => handleSelect('student')}>Student</button>
        </li>
      </ul>
    </aside>
  );
};




// Inline Styles
const styles = {
  sidebar: {
    height: '100vh', // Full viewport height
    width: '200px', // Sidebar width
    backgroundColor: 'grey', // Sidebar background color
    color: '#fff',
    padding: '10px',
    position: 'fixed', // Fixed position to stay on the left side
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'flex-start',
  },
  title: {
    margin: '0 0 20px 0',
    fontSize: '20px',
    fontWeight: 'bold',
  },
  list: {
    listStyleType: 'none',
    padding: 0,
  },
  listItem: {
    margin: '10px 0',
    padding: '10px 15px',
    cursor: 'pointer',
    borderRadius: '5px',
    transition: 'background-color 0.3s',
  },
  listItemHover: {
    backgroundColor: '#00509E', // Hover effect for the list items
  },
};

export default SideNar;
