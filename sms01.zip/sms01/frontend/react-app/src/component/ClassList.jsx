// src/components/ClassList.js
import React, { useEffect, useState } from 'react';
import axios from 'axios';

const ClassList = () => {
  const [classes, setClasses] = useState([]);
  const [loading, setLoading] = useState(true);

  // Function to fetch classes from the backend
  const fetchClasses = async () => {
    try {
      const response = await axios.get('http://localhost:5000/classes'); // Ensure the backend endpoint is correct
      setClasses(response.data);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching classes:', error);
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchClasses();
  }, []);

  if (loading) {
    return <div className="loading">Loading...</div>;
  }

  return (
    <div className="list-container"> {/* Updated class name to match the shared CSS */}
      <h2>Class List</h2>
      <ul className="list"> {/* Updated class name to match the shared CSS */}
        {classes.map((classItem) => (
          <li key={classItem._id}>
            Name: {classItem.name}, Description: {classItem.description}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ClassList;
